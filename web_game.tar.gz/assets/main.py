import pygame
import random
import sys
import math
import asyncio
import traceback

# 是否在浏览器（pygbag/emscripten）环境中运行
IS_WEB = sys.platform == 'emscripten'
FONT_PATH = 'font/simhei.ttf'  # 网页版中文字体文件（随游戏一起打包）

# ===== 错误显示层（网页版调试用）：任何异常都会画到游戏画布上 =====
def _show_error(e):
    # 方案一：直接写到页面 HTML（pygbag 的 platform.document），任何阶段都能显示
    try:
        import platform as _plt
        _tb = traceback.format_exc()
        _esc = _tb.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        _html = '<pre style="color:#ff5050;font-family:monospace;font-size:14px;white-space:pre-wrap;padding:10px;background:#111;min-height:100vh">' + _esc + '</pre>'
        _plt.document.body.innerHTML = _html
    except Exception:
        pass
    # 方案二：画到游戏画布上
    try:
        surf = pygame.display.get_surface()
        if surf is None:
            return
        lines = traceback.format_exc().split('\n')
        surf.fill((0, 0, 0))
        f = pygame.font.Font(None, 18)
        y = 5
        for line in lines[-16:]:
            for sub in line.split('\n'):
                if sub:
                    s = f.render(sub[:46], True, (255, 80, 80))
                    surf.blit(s, (5, y))
                    y += 15
        pygame.display.flip()
    except Exception:
        pass

sys.excepthook = _show_error

def _page_mark(text):
    # 把运行状态写入浏览器标签标题，便于远程诊断主循环是否启动
    try:
        import platform as _plt
        _plt.document.title = '雷霆战机[' + text + ']'
    except Exception:
        pass

# 初始化pygame
pygame.init()
try:
    pygame.key.stop_text_input()
except Exception:
    pass

# 窗口设置
SCREEN_WIDTH = 480
SCREEN_HEIGHT = 700
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("雷霆战机 暴走强化版")

# 颜色定义
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 120, 255)
CYAN = (0, 255, 255)
ORANGE = (255, 165, 0)
DARK_ORANGE = (255, 140, 0)
DARK_RED = (178, 34, 34)
PINK = (255, 105, 180)
GOLD = (255, 215, 0)
PURPLE = (138, 43, 226)
DARK_PURPLE = (75, 0, 130)
GRAY = (100, 100, 100)
YELLOW = (255, 255, 0)
BTN_BG = (50, 50, 50)
BTN_BORDER = (200, 200, 200)

# 时钟 & FPS
clock = pygame.time.Clock()
FPS = 60

# 精灵组
bullet_group = pygame.sprite.Group()
laser_group = pygame.sprite.Group()
enemy_group = pygame.sprite.Group()
powerup_group = pygame.sprite.Group()
explosion_group = pygame.sprite.Group()
boss_bullet_group = pygame.sprite.Group()
enemy_bullet_group = pygame.sprite.Group()
star_group = pygame.sprite.Group()
all_sprites = pygame.sprite.Group()

# UI按钮矩形
btn_pause = pygame.Rect(SCREEN_WIDTH - 110, 40, 90, 30)
btn_restart = pygame.Rect(SCREEN_WIDTH - 110, 80, 90, 30)


# 字体加载函数（网页版使用随游戏打包的中文字体文件）
def get_font(size):
    try:
        if IS_WEB:
            return pygame.font.Font(FONT_PATH, size)
        return pygame.font.SysFont("simhei", size)
    except:
        return pygame.font.Font(None, size)


# ---------------------- 星空背景类 ----------------------
class Star(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.size = random.randint(1, 3)
        self.image = pygame.Surface((self.size, self.size))
        self.image.fill(WHITE)
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, SCREEN_WIDTH)
        self.rect.y = random.randint(0, SCREEN_HEIGHT)
        self.speed = random.randint(1, 3)

    def update(self):
        self.rect.y += self.speed
        if self.rect.top > SCREEN_HEIGHT:
            self.rect.bottom = 0
            self.rect.x = random.randint(0, SCREEN_WIDTH)


# ---------------------- 爆炸特效类 ----------------------
class Explosion(pygame.sprite.Sprite):
    def __init__(self, x, y, max_radius=40):
        super().__init__()
        self.max_radius = max_radius
        self.radius = 8
        self.alpha = 255
        self.image = pygame.Surface((max_radius*2, max_radius*2), pygame.SRCALPHA)
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

    def update(self):
        self.radius += 2
        self.alpha -= 12
        if self.alpha <= 0 or self.radius >= self.max_radius:
            self.kill()
            return
        self.image.fill((0, 0, 0, 0))
        pygame.draw.circle(self.image, (*YELLOW, self.alpha), (self.max_radius, self.max_radius), self.radius)


# ---------------------- 玩家飞机类 ----------------------
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.base_image = pygame.Surface((40, 50), pygame.SRCALPHA)
        pygame.draw.polygon(self.base_image, BLUE, [(20, 0), (0, 50), (40, 50)])
        self.image = self.base_image.copy()
        self.rect = self.image.get_rect()
        self.rect.centerx = SCREEN_WIDTH // 2
        self.rect.bottom = SCREEN_HEIGHT - 20
        self.speed = 7
        self.last_shot = 0
        self.shot_cd = 180
        self.bullet_level = 1  # 基础火力等级 1-3

        # 大招系统
        self.max_skill = 3
        self.skill_count = 1
        self.last_charge = pygame.time.get_ticks()
        self.charge_interval = 10000

        # 受击无敌帧
        self.invincible = False
        self.invincible_time = 0
        self.invincible_duration = 1500  # 1.5秒无敌
        self.flash_cd = 100

        # 激光暴走系统
        self.max_rage = 100
        self.rage_energy = 0
        self.is_raging = False
        self.rage_duration = 5000  # 暴走持续5秒
        self.rage_start_time = 0
        self.last_laser_shot = 0
        self.laser_cd = 150

    def update(self):
        now = pygame.time.get_ticks()
        keys = pygame.key.get_pressed()
        # 触屏虚拟方向键合成（仅网页版）
        if IS_WEB and virtual_keys:
            keys = list(keys)
            for k in virtual_keys:
                keys[k] = 1

        # 移动控制
        if keys[pygame.K_a] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_d] and self.rect.right < SCREEN_WIDTH:
            self.rect.x += self.speed
        if keys[pygame.K_w] and self.rect.top > 0:
            self.rect.y -= self.speed
        if keys[pygame.K_s] and self.rect.bottom < SCREEN_HEIGHT:
            self.rect.y += self.speed

        # 无敌帧逻辑
        if self.invincible:
            if now - self.invincible_time > self.invincible_duration:
                self.invincible = False
                self.image = self.base_image.copy()
            else:
                # 闪烁效果
                if (now // self.flash_cd) % 2 == 0:
                    self.image.set_alpha(80)
                else:
                    self.image.set_alpha(255)

        # 暴走状态逻辑
        if self.is_raging:
            if now - self.rage_start_time > self.rage_duration:
                self.is_raging = False
                # 暴走结束，清除所有残留激光（防止激光一直不消失）
                for laser in laser_group:
                    laser.kill()
            else:
                # 暴走期间激光跟随玩家左右移动
                for laser in laser_group:
                    laser.follow_player(self.rect.centerx)
                # 暴走时发射激光
                if now - self.last_laser_shot > self.laser_cd:
                    self.last_laser_shot = now
                    self._fire_laser()
        else:
            # 普通自动射击
            if now - self.last_shot > self.shot_cd:
                self.last_shot = now
                self._fire_bullet()

        # 大招自动充能
        if self.skill_count < self.max_skill:
            if now - self.last_charge >= self.charge_interval:
                self.skill_count += 1
                self.last_charge = now

    def _fire_bullet(self):
        cx = self.rect.centerx
        top = self.rect.top
        new_bullets = []

        # 基础火力 + 关卡额外霰弹
        total_level = self.bullet_level + (level - 1)  # 每过一关额外加1级霰弹

        if total_level == 1:
            new_bullets.append(Bullet(cx, top))
        elif total_level == 2:
            new_bullets.append(Bullet(cx - 10, top))
            new_bullets.append(Bullet(cx + 10, top))
        elif total_level == 3:
            new_bullets.append(Bullet(cx - 15, top))
            new_bullets.append(Bullet(cx, top))
            new_bullets.append(Bullet(cx + 15, top))
        elif total_level == 4:
            new_bullets.append(Bullet(cx - 18, top))
            new_bullets.append(Bullet(cx, top))
            new_bullets.append(Bullet(cx + 18, top))
            # 两侧斜向霰弹
            new_bullets.append(SpreadBullet(cx - 20, top, math.radians(-15)))
            new_bullets.append(SpreadBullet(cx + 20, top, math.radians(15)))
        else:  # 5级及以上
            new_bullets.append(Bullet(cx - 18, top))
            new_bullets.append(Bullet(cx, top))
            new_bullets.append(Bullet(cx + 18, top))
            # 四发散射
            new_bullets.append(SpreadBullet(cx - 25, top, math.radians(-20)))
            new_bullets.append(SpreadBullet(cx - 10, top, math.radians(-8)))
            new_bullets.append(SpreadBullet(cx + 10, top, math.radians(8)))
            new_bullets.append(SpreadBullet(cx + 25, top, math.radians(20)))

        bullet_group.add(*new_bullets)
        all_sprites.add(*new_bullets)

    def _fire_laser(self):
        # 暴走发射两道贯穿激光
        laser1 = Laser(self.rect.centerx - 12, self.rect.top, offset_x=-12)
        laser2 = Laser(self.rect.centerx + 12, self.rect.top, offset_x=12)
        laser_group.add(laser1, laser2)
        all_sprites.add(laser1, laser2)

    def use_skill(self):
        if self.skill_count <= 0:
            return
        self.skill_count -= 1
        if self.skill_count < self.max_skill:
            self.last_charge = pygame.time.get_ticks()

        cx = self.rect.centerx
        top = self.rect.top

        # 15发散射霰弹
        bullet_count = 15
        spread_angle = 120
        start_angle = -spread_angle // 2
        angle_step = spread_angle / (bullet_count - 1)
        for i in range(bullet_count):
            angle = start_angle + i * angle_step
            rad = math.radians(angle)
            bullet = SpreadBullet(cx, top, rad)
            bullet_group.add(bullet)
            all_sprites.add(bullet)

        # 1颗强力炸弹
        bomb = PowerBomb(cx, top)
        bullet_group.add(bomb)
        all_sprites.add(bomb)

    def get_hit(self):
        """玩家受击，无敌时不扣血"""
        if self.invincible or self.is_raging:
            return False
        self.invincible = True
        self.invincible_time = pygame.time.get_ticks()
        return True

    def add_rage(self, amount):
        """增加暴走能量"""
        if self.is_raging:
            return
        self.rage_energy = min(self.max_rage, self.rage_energy + amount)
        if self.rage_energy >= self.max_rage:
            self.trigger_rage()

    def trigger_rage(self):
        """触发激光暴走"""
        self.is_raging = True
        self.rage_start_time = pygame.time.get_ticks()
        self.rage_energy = 0
        # 清屏所有敌方子弹
        for b in enemy_bullet_group:
            b.kill()
        for b in boss_bullet_group:
            b.kill()


# ---------------------- 普通玩家子弹 ----------------------
class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((4, 12))
        self.image.fill(GREEN)
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.bottom = y
        self.speed = 12
        self.damage = 1

    def update(self):
        self.rect.y -= self.speed
        if self.rect.bottom < 0:
            self.kill()


# ---------------------- 斜向霰弹 ----------------------
class SpreadBullet(pygame.sprite.Sprite):
    def __init__(self, x, y, angle_rad):
        super().__init__()
        self.image = pygame.Surface((4, 10))
        self.image.fill(CYAN)
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.centery = y
        self.speed = 11
        self.damage = 1
        self.vx = self.speed * math.sin(angle_rad)
        self.vy = -self.speed * math.cos(angle_rad)

    def update(self):
        self.rect.x += self.vx
        self.rect.y += self.vy
        if (self.rect.bottom < 0 or self.rect.top > SCREEN_HEIGHT or
            self.rect.right < 0 or self.rect.left > SCREEN_WIDTH):
            self.kill()


# ---------------------- 强力炸弹 ----------------------
class PowerBomb(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((16, 24), pygame.SRCALPHA)
        pygame.draw.ellipse(self.image, GOLD, (0, 0, 16, 24))
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.bottom = y
        self.speed = 8
        self.damage = 20

    def update(self):
        self.rect.y -= self.speed
        if self.rect.bottom < 0:
            self.kill()


# ---------------------- 暴走激光（贯穿） ----------------------
class Laser(pygame.sprite.Sprite):
    def __init__(self, x, y, offset_x=0):
        super().__init__()
        self.offset_x = offset_x  # 相对玩家的固定偏移，用于跟随玩家
        self.image = pygame.Surface((8, SCREEN_HEIGHT), pygame.SRCALPHA)
        pygame.draw.rect(self.image, (0, 255, 255, 200), (2, 0, 4, SCREEN_HEIGHT))
        pygame.draw.rect(self.image, (255, 255, 255, 255), (3, 0, 2, SCREEN_HEIGHT))
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.bottom = y
        self.damage = 2  # 每帧伤害
        self.pierce = True  # 贯穿

    def update(self):
        # 激光固定从玩家射向屏幕顶端，不移动；
        # 暴走期间由 Player.update 调用 follow_player 跟随玩家左右移动
        pass

    def follow_player(self, player_centerx):
        # 暴走期间激光跟随玩家，保持固定偏移
        self.rect.centerx = player_centerx + self.offset_x


# ---------------------- 敌方子弹类 ----------------------
class EnemyBullet(pygame.sprite.Sprite):
    def __init__(self, x, y, speed=6, angle_rad=0):
        super().__init__()
        self.image = pygame.Surface((6, 14))
        self.image.fill(RED)
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.top = y
        self.speed = speed
        self.vx = speed * math.sin(angle_rad)
        self.vy = speed * math.cos(angle_rad)

    def update(self):
        self.rect.x += self.vx
        self.rect.y += self.vy
        if self.rect.top > SCREEN_HEIGHT or self.rect.bottom < 0:
            self.kill()
        if self.rect.left < 0 or self.rect.right > SCREEN_WIDTH:
            self.kill()


# ---------------------- 多类型敌机类（行为差异化） ----------------------
class Enemy(pygame.sprite.Sprite):
    def __init__(self, speed_min=3, speed_max=6, enemy_type='small'):
        super().__init__()
        self.enemy_type = enemy_type

        # 基础属性配置
        if enemy_type == 'small':
            size_w, size_h = 36, 42
            self.hp = 2
            self.shot_cd_min, self.shot_cd_max = 1800, 3500
            main_color = RED
            self.score = 10
            self.move_type = 'straight'
            self.shot_type = 'single'
        elif enemy_type == 'medium':
            size_w, size_h = 44, 52
            self.hp = 4
            self.shot_cd_min, self.shot_cd_max = 1200, 2200
            main_color = DARK_ORANGE
            self.score = 20
            self.move_type = 'zigzag'  # Z字走位
            self.shot_type = 'single'
            self.zigzag_amp = 30  # 摆动幅度
            self.zigzag_speed = 0.03
            self.start_x = 0
        else:  # heavy重型
            size_w, size_h = 56, 64
            self.hp = 8
            self.shot_cd_min, self.shot_cd_max = 1000, 1800
            main_color = DARK_RED
            self.score = 40
            self.move_type = 'straight'
            self.shot_type = 'spread'  # 三发散射

        self.base_image = pygame.Surface((size_w, size_h), pygame.SRCALPHA)
        pygame.draw.polygon(self.base_image, main_color, [(size_w//2, size_h), (0, 0), (size_w, 0)])
        self.image = self.base_image.copy()

        # 带道具敌机金边
        self.has_powerup = random.random() < 0.18
        self.powerup_type = random.choices(['life', 'upgrade'], weights=[1, 4], k=1)[0]  # 生命道具概率降低（40%->20%）
        if self.has_powerup:
            pygame.draw.polygon(self.image, GOLD, [(size_w//2, size_h), (0, 0), (size_w, 0)], 2)

        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, SCREEN_WIDTH - self.rect.width)
        self.rect.y = random.randint(-100, -40)
        self.speed = random.randint(speed_min, speed_max)

        # Z字移动初始位置
        if self.move_type == 'zigzag':
            self.start_x = self.rect.x
            self.move_offset = 0

        # 首次射击延迟0.5~1秒
        self.last_shot = pygame.time.get_ticks() + random.randint(500, 1000)
        self.shot_cd = random.randint(self.shot_cd_min, self.shot_cd_max)

        # 随关卡提升难度：冷却更短、子弹更快更多（第1关保持原样）
        lv_bonus = max(0, level - 1)
        self.shot_cd = max(400, int(self.shot_cd * (0.75 ** lv_bonus)))  # 每关射击冷却缩短25%
        self.bullet_speed = 5 + lv_bonus      # 散射子弹速度：第1关5 / 第2关6 / 第3关7；单发在此基础上+1
        self.shot_way = 1 + lv_bonus          # 弹道数：第1关1 / 第2关2 / 第3关3（单发敌机一次发射数量）

    def update(self):
        now = pygame.time.get_ticks()

        # 移动逻辑
        if self.move_type == 'straight':
            self.rect.y += self.speed
        elif self.move_type == 'zigzag':
            self.rect.y += self.speed
            self.move_offset += self.zigzag_speed
            self.rect.x = self.start_x + math.sin(self.move_offset) * self.zigzag_amp
            # 边界限制
            self.rect.x = max(0, min(SCREEN_WIDTH - self.rect.width, self.rect.x))

        # 射击逻辑（关卡越高，子弹越多越快）
        if now - self.last_shot > self.shot_cd and self.rect.y > 0:
            self.last_shot = now
            if self.shot_type == 'single':
                # 关卡越高一次发射越多发（横向错开）
                if self.shot_way >= 3:
                    offsets = [-16, 0, 16]
                elif self.shot_way >= 2:
                    offsets = [-8, 8]
                else:
                    offsets = [0]
                for ox in offsets:
                    bullet = EnemyBullet(self.rect.centerx + ox, self.rect.bottom, self.bullet_speed + 1)
                    enemy_bullet_group.add(bullet)
                    all_sprites.add(bullet)
            elif self.shot_type == 'spread':
                # 散射；第3关起增至五发，子弹更快
                angles = [-40, -20, 0, 20, 40] if self.shot_way >= 3 else [-20, 0, 20]
                for angle in angles:
                    rad = math.radians(angle)
                    bullet = EnemyBullet(self.rect.centerx, self.rect.bottom, self.bullet_speed, rad)
                    enemy_bullet_group.add(bullet)
                    all_sprites.add(bullet)

        if self.rect.top > SCREEN_HEIGHT:
            self.kill()


# ---------------------- BOSS类 ----------------------
class Boss(pygame.sprite.Sprite):
    def __init__(self, hp=100, level=1):
        super().__init__()
        self.image = pygame.Surface((120, 80), pygame.SRCALPHA)
        pygame.draw.polygon(self.image, DARK_PURPLE, [(60, 80), (0, 0), (120, 0)])
        pygame.draw.rect(self.image, PURPLE, (40, 20, 40, 40))
        self.rect = self.image.get_rect()
        self.rect.centerx = SCREEN_WIDTH // 2
        self.rect.top = 30
        self.max_hp = hp
        self.hp = hp
        self.speed = 2
        self.direction = 1
        self.last_shot = 0
        self.shot_cd = max(400, 800 - (level-1)*150)  # 关卡越高射击越快
        self.level = level
        self.last_laser_damage_time = 0  # 激光伤害周期结算计时（防暴走秒杀BOSS）

    def update(self):
        self.rect.x += self.speed * self.direction
        if self.rect.left <= 0 or self.rect.right >= SCREEN_WIDTH:
            self.direction *= -1

        now = pygame.time.get_ticks()
        if now - self.last_shot > self.shot_cd:
            self.last_shot = now
            # 关卡越高子弹越多
            if self.level == 1:
                bullets = [EnemyBullet(self.rect.centerx, self.rect.bottom, 7)]
            elif self.level == 2:
                bullets = [
                    EnemyBullet(self.rect.centerx, self.rect.bottom, 7),
                    EnemyBullet(self.rect.centerx - 35, self.rect.bottom, 7),
                    EnemyBullet(self.rect.centerx + 35, self.rect.bottom, 7)
                ]
            else:
                bullets = [
                    EnemyBullet(self.rect.centerx, self.rect.bottom, 7),
                    EnemyBullet(self.rect.centerx - 30, self.rect.bottom, 7, math.radians(-10)),
                    EnemyBullet(self.rect.centerx + 30, self.rect.bottom, 7, math.radians(10)),
                    EnemyBullet(self.rect.centerx - 50, self.rect.bottom, 7, math.radians(-20)),
                    EnemyBullet(self.rect.centerx + 50, self.rect.bottom, 7, math.radians(20)),
                ]
            boss_bullet_group.add(*bullets)
            all_sprites.add(*bullets)


# ---------------------- 道具类 ----------------------
class PowerUp(pygame.sprite.Sprite):
    def __init__(self, x, y, power_type):
        super().__init__()
        self.type = power_type
        self.image = pygame.Surface((22, 22), pygame.SRCALPHA)
        if self.type == 'life':
            pygame.draw.circle(self.image, PINK, (11, 11), 11)
        elif self.type == 'upgrade':
            pygame.draw.circle(self.image, GOLD, (11, 11), 11)
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.centery = y
        self.speed = 3

    def update(self):
        self.rect.y += self.speed
        if self.rect.top > SCREEN_HEIGHT:
            self.kill()


# ---------------------- 重新开始游戏 ----------------------
def restart_game():
    global score, life, game_over, game_win, is_paused, player, boss
    global next_boss_score, enemy_spawn_interval, enemy_speed_min, enemy_speed_max
    global level, boss_warning_time, level_up_time, life_pu_got

    all_sprites.empty()
    bullet_group.empty()
    laser_group.empty()
    enemy_group.empty()
    powerup_group.empty()
    explosion_group.empty()
    boss_bullet_group.empty()
    enemy_bullet_group.empty()
    star_group.empty()

    for _ in range(60):
        star_group.add(Star())

    player = Player()
    all_sprites.add(player)

    score = 0
    life = 3
    game_over = False
    game_win = False
    is_paused = False
    boss = None
    level = 1
    next_boss_score = 500
    enemy_spawn_interval = 600
    enemy_speed_min = 3
    enemy_speed_max = 5
    boss_warning_time = 0
    level_up_time = 0
    life_pu_got = 0  # 本局已拾取的生命道具数（上限2）
    pygame.time.set_timer(SPAWN_ENEMY, enemy_spawn_interval)


# ---------------------- 游戏初始化 ----------------------
SPAWN_ENEMY = pygame.USEREVENT + 1
player = Player()
all_sprites.add(player)
for _ in range(60):
    star_group.add(Star())

enemy_spawn_interval = 600
enemy_speed_min = 3
enemy_speed_max = 5
pygame.time.set_timer(SPAWN_ENEMY, enemy_spawn_interval)

score = 0
life = 3
game_over = False
game_win = False
is_paused = False
boss = None
next_boss_score = 500
level = 1
boss_warning_time = 0
level_up_time = 0
life_pu_got = 0  # 本局已拾取的生命道具数（上限2）

font = get_font(24)
big_font = get_font(48)
title_font = get_font(56)


# ---------------------- 触屏虚拟控制（手机网页版） ----------------------
virtual_keys = set()  # 当前按住的虚拟方向键（键码集合）
touch_move = {'active': False, 'sx': 0, 'sy': 0, 'last': (0, 0)}  # 虚拟摇杆状态
MOVE_ZONE = pygame.Rect(0, SCREEN_HEIGHT // 2, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)  # 左下移动区
SKILL_BTN = pygame.Rect(SCREEN_WIDTH - 140, SCREEN_HEIGHT - 170, 120, 120)  # 右下大招键


def touch_press(pos):
    """触摸/鼠标按下：摇杆区激活移动摇杆，技能区释放大招"""
    if not IS_WEB:
        return
    if MOVE_ZONE.collidepoint(pos):
        touch_move['active'] = True
        touch_move['sx'], touch_move['sy'] = pos
        touch_move['last'] = pos
        update_touch_move(pos)
    elif SKILL_BTN.collidepoint(pos):
        if not game_over and not game_win and not is_paused:
            player.use_skill()


def touch_release(pos):
    """触摸/鼠标抬起：清空摇杆方向"""
    if not IS_WEB:
        return
    touch_move['active'] = False
    for k in (pygame.K_a, pygame.K_d, pygame.K_w, pygame.K_s):
        virtual_keys.discard(k)


def update_touch_move(pos):
    """根据手指相对起点的位移合成方向键（带死区）"""
    if not touch_move['active']:
        return
    touch_move['last'] = pos
    for k in (pygame.K_a, pygame.K_d, pygame.K_w, pygame.K_s):
        virtual_keys.discard(k)
    dx = pos[0] - touch_move['sx']
    dy = pos[1] - touch_move['sy']
    if abs(dx) > 24:
        virtual_keys.add(pygame.K_d if dx > 0 else pygame.K_a)
    if abs(dy) > 24:
        virtual_keys.add(pygame.K_s if dy > 0 else pygame.K_w)


def draw_touch_ui():
    """绘制触屏控制界面（仅网页版显示）"""
    if not IS_WEB:
        return
    zone = pygame.Surface((MOVE_ZONE.width, MOVE_ZONE.height), pygame.SRCALPHA)
    zone.fill((255, 255, 255, 16))
    screen.blit(zone, MOVE_ZONE.topleft)
    if touch_move['active']:
        pygame.draw.circle(screen, (255, 255, 255, 110), touch_move['last'], 26, 3)
        pygame.draw.line(screen, (255, 255, 255, 110), (touch_move['sx'], touch_move['sy']), touch_move['last'], 3)
    skill_surf = pygame.Surface((SKILL_BTN.width, SKILL_BTN.height), pygame.SRCALPHA)
    pygame.draw.circle(skill_surf, (0, 180, 255, 80), (SKILL_BTN.width // 2, SKILL_BTN.height // 2), 48)
    pygame.draw.circle(skill_surf, (255, 255, 255, 200), (SKILL_BTN.width // 2, SKILL_BTN.height // 2), 48, 3)
    screen.blit(skill_surf, SKILL_BTN.topleft)
    st = font.render("技能", True, WHITE)
    screen.blit(st, st.get_rect(center=SKILL_BTN.center))


# ---------------------- 主循环 ----------------------
async def main():
    _page_mark('运行')
    global running, score, life, game_over, game_win, is_paused, boss
    global next_boss_score, enemy_spawn_interval, enemy_speed_min, enemy_speed_max
    global level, boss_warning_time, level_up_time, life_pu_got
    running = True
    while running:
        clock.tick(FPS)
        now_tick = pygame.time.get_ticks()

        # 事件处理
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == SPAWN_ENEMY and not game_over and not game_win and not is_paused:
                if boss is None or random.random() < 0.4:
                    if level == 1:
                        type_pool = ['small']
                    elif level == 2:
                        type_pool = ['small', 'small', 'medium']
                    else:
                        type_pool = ['small', 'medium', 'medium', 'heavy']
                    enemy_type = random.choice(type_pool)
                    enemy = Enemy(enemy_speed_min, enemy_speed_max, enemy_type)
                    enemy_group.add(enemy)
                    all_sprites.add(enemy)

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    restart_game()
                if not game_over and not game_win:
                    if event.key == pygame.K_p:
                        is_paused = not is_paused
                    if event.key == pygame.K_SPACE and not is_paused:
                        player.use_skill()

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mx, my = event.pos
                # 网页版：游戏结束/通关后点击任意处重开
                if IS_WEB and (game_over or game_win):
                    restart_game()
                if btn_pause.collidepoint(mx, my) and not game_over and not game_win:
                    is_paused = not is_paused
                if btn_restart.collidepoint(mx, my):
                    restart_game()
                # 触屏控制：移动摇杆 / 技能按钮
                touch_press((mx, my))

            if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                touch_release(event.pos)

            if event.type == pygame.MOUSEMOTION and event.buttons[0]:
                touch_move['last'] = event.pos
                update_touch_move(event.pos)

        # 游戏逻辑更新
        if not game_over and not game_win and not is_paused:
            star_group.update()
            all_sprites.update()
            explosion_group.update()

            # 1. 普通子弹击中敌机
            hits = pygame.sprite.groupcollide(enemy_group, bullet_group, False, True)
            for enemy, bullets in hits.items():
                total_dmg = sum(b.damage for b in bullets)
                enemy.hp -= total_dmg
                if enemy.hp <= 0:
                    score += enemy.score
                    player.add_rage(enemy.score // 4)  # 击杀加少量暴走能量
                    explosion_group.add(Explosion(enemy.rect.centerx, enemy.rect.centery))
                    if enemy.has_powerup:
                        pu_type = enemy.powerup_type
                        if pu_type == 'life' and life_pu_got >= 2:
                            pu_type = 'upgrade'  # 生命道具本局已达上限，改为升级道具
                        pu = PowerUp(enemy.rect.centerx, enemy.rect.centery, pu_type)
                        powerup_group.add(pu)
                        all_sprites.add(pu)
                    enemy.kill()

            # 2. 激光击中敌机（贯穿，持续伤害）
            if laser_group:
                laser_hits = pygame.sprite.groupcollide(enemy_group, laser_group, False, False)
                for enemy, lasers in laser_hits.items():
                    enemy.hp -= len(lasers) * lasers[0].damage
                    if enemy.hp <= 0:
                        score += enemy.score
                        player.add_rage(enemy.score // 4)
                        explosion_group.add(Explosion(enemy.rect.centerx, enemy.rect.centery))
                        if enemy.has_powerup:
                            pu_type = enemy.powerup_type
                            if pu_type == 'life' and life_pu_got >= 2:
                                pu_type = 'upgrade'  # 生命道具本局已达上限，改为升级道具
                            pu = PowerUp(enemy.rect.centerx, enemy.rect.centery, pu_type)
                            powerup_group.add(pu)
                            all_sprites.add(pu)
                        enemy.kill()

            # 3. 子弹攻击BOSS（一次性扣血，彻底防空指针）
            if boss is not None:
                total_damage = 0
                # 普通子弹伤害
                boss_hits = pygame.sprite.spritecollide(boss, bullet_group, True)
                total_damage += sum(b.damage for b in boss_hits)
                # 激光伤害（周期结算：每500ms一次、每道1点，暴走5秒约20点，不能秒杀BOSS）
                laser_hits_boss = pygame.sprite.spritecollide(boss, laser_group, False)
                if laser_hits_boss and now_tick - boss.last_laser_damage_time >= 500:
                    boss.last_laser_damage_time = now_tick
                    total_damage += len(laser_hits_boss) * 1

                if total_damage > 0:
                    boss.hp -= total_damage
                    if boss.hp <= 0:
                        score += 200
                        player.add_rage(15)
                        explosion_group.add(Explosion(boss.rect.centerx, boss.rect.centery, 80))
                        pu1 = PowerUp(boss.rect.centerx - 30, boss.rect.centery, 'upgrade')
                        pu2 = PowerUp(boss.rect.centerx + 30, boss.rect.centery, 'upgrade')
                        # BOSS生命道具：50%概率，且整局最多2个
                        boss_life_type = 'life' if (random.random() < 0.5 and life_pu_got < 2) else 'upgrade'
                        pu3 = PowerUp(boss.rect.centerx, boss.rect.centery, boss_life_type)
                        powerup_group.add(pu1, pu2, pu3)
                        all_sprites.add(pu1, pu2, pu3)
                        boss.kill()
                        boss = None

                        if level >= 3:
                            game_win = True
                        else:
                            level += 1
                            level_up_time = now_tick
                            enemy_spawn_interval = max(350, enemy_spawn_interval - 100)
                            enemy_speed_min += 1
                            enemy_speed_max += 1
                            pygame.time.set_timer(SPAWN_ENEMY, enemy_spawn_interval)
                            next_boss_score = score + 800

            # 4. 生成BOSS
            if boss is None and not game_win and score >= next_boss_score:
                boss_hp = 100 + (level - 1) * 80
                boss = Boss(hp=boss_hp, level=level)
                all_sprites.add(boss)
                boss_warning_time = now_tick

            # 5. 拾取道具
            get_pu = pygame.sprite.spritecollide(player, powerup_group, True)
            for pu in get_pu:
                if pu.type == 'life':
                    life += 1
                    life_pu_got += 1  # 计入本局生命道具拾取数
                elif pu.type == 'upgrade':
                    if player.bullet_level < 3:
                        player.bullet_level += 1
                    player.add_rage(8)  # 吃升级道具加少量暴走能量

            # 6. 敌机撞玩家
            crash = pygame.sprite.spritecollide(player, enemy_group, True)
            if crash:
                if player.get_hit():
                    life -= 1
                    explosion_group.add(Explosion(player.rect.centerx, player.rect.centery, 30))
                    if life <= 0:
                        game_over = True

            # 7. 敌机子弹击中玩家
            enemy_bullet_crash = pygame.sprite.spritecollide(player, enemy_bullet_group, True)
            if enemy_bullet_crash:
                if player.get_hit():
                    life -= 1
                    if life <= 0:
                        game_over = True

            # 8. BOSS子弹击中玩家
            if boss is not None:
                boss_crash = pygame.sprite.spritecollide(player, boss_bullet_group, True)
                if boss_crash:
                    if player.get_hit():
                        life -= 1
                        if life <= 0:
                            game_over = True

            # 9. BOSS机身撞玩家
            if boss is not None and pygame.sprite.collide_rect(player, boss):
                if player.get_hit():
                    life -= 1
                    player.rect.centerx = SCREEN_WIDTH // 2
                    player.rect.bottom = SCREEN_HEIGHT - 20
                    if life <= 0:
                        game_over = True

        # ========= 画面绘制 =========
        screen.fill(BLACK)
        star_group.draw(screen)
        all_sprites.draw(screen)
        explosion_group.draw(screen)

        # 左上角状态
        screen.blit(font.render(f"分数: {score}", True, WHITE), (10, 10))
        screen.blit(font.render(f"生命: {life}", True, WHITE), (10, 40))
        screen.blit(font.render(f"大招: {player.skill_count}/{player.max_skill}", True, WHITE), (10, 70))

        # 大招充能条
        if player.skill_count < player.max_skill and not game_over and not game_win:
            bar_bg = pygame.Rect(10, 95, 100, 6)
            pygame.draw.rect(screen, GRAY, bar_bg)
            charge_progress = (now_tick - player.last_charge) / player.charge_interval
            charge_progress = min(charge_progress, 1.0)
            pygame.draw.rect(screen, GOLD, (10, 95, 100 * charge_progress, 6))

        # 暴走能量条
        screen.blit(font.render(f"暴走能量", True, WHITE), (10, 108))
        rage_bar_bg = pygame.Rect(10, 130, 100, 8)
        pygame.draw.rect(screen, GRAY, rage_bar_bg)
        rage_progress = player.rage_energy / player.max_rage
        pygame.draw.rect(screen, CYAN, (10, 130, 100 * rage_progress, 8))

        screen.blit(font.render(f"火力: Lv.{player.bullet_level + level - 1}", True, WHITE), (10, 145))
        screen.blit(font.render(f"第 {level} 关 / 共3关", True, WHITE), (SCREEN_WIDTH - 140, 10))

        # 暴走状态提示
        if player.is_raging:
            screen.blit(big_font.render("激光暴走！", True, CYAN), (SCREEN_WIDTH//2 - 100, 60))

        # BOSS血条
        if boss is not None:
            pygame.draw.rect(screen, GRAY, (50, 35, SCREEN_WIDTH - 100, 12))
            hp_width = (SCREEN_WIDTH - 100) * max(boss.hp, 0) / boss.max_hp
            pygame.draw.rect(screen, RED, (50, 35, hp_width, 12))
            screen.blit(font.render("BOSS", True, WHITE), (SCREEN_WIDTH//2 - 25, 32))

        # UI按钮
        pygame.draw.rect(screen, BTN_BG, btn_pause)
        pygame.draw.rect(screen, BTN_BORDER, btn_pause, 2)
        btn_text = "继续" if is_paused else "暂停"
        text_surf = font.render(btn_text, True, WHITE)
        screen.blit(text_surf, text_surf.get_rect(center=btn_pause.center))

        pygame.draw.rect(screen, BTN_BG, btn_restart)
        pygame.draw.rect(screen, BTN_BORDER, btn_restart, 2)
        restart_surf = font.render("重新开始", True, WHITE)
        screen.blit(restart_surf, restart_surf.get_rect(center=btn_restart.center))

        # BOSS来袭警告
        if boss_warning_time > 0 and now_tick - boss_warning_time < 2000:
            warning_surf = big_font.render("BOSS 来袭！", True, RED)
            if (now_tick // 200) % 2 == 0:
                screen.blit(warning_surf, warning_surf.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2)))

        # 关卡升级提示
        if level_up_time > 0 and now_tick - level_up_time < 2000:
            level_surf = big_font.render(f"第 {level} 关", True, GOLD)
            screen.blit(level_surf, level_surf.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2)))

        # 暂停界面
        if is_paused:
            pause_font = get_font(40)
            screen.blit(pause_font.render("游戏暂停", True, WHITE), (SCREEN_WIDTH//2 - 80, SCREEN_HEIGHT//2 - 50))
            screen.blit(font.render("按 P 继续 | 按 R 重新开始", True, WHITE), (SCREEN_WIDTH//2 - 110, SCREEN_HEIGHT//2 + 20))

        # 游戏失败界面
        if game_over:
            over_font = get_font(40)
            screen.blit(over_font.render("游戏结束！", True, RED), (SCREEN_WIDTH//2 - 100, SCREEN_HEIGHT//2 - 50))
            screen.blit(font.render(f"最终分数：{score}", True, WHITE), (SCREEN_WIDTH//2 - 90, SCREEN_HEIGHT//2 + 10))
            screen.blit(font.render("按 R 重新开始", True, WHITE), (SCREEN_WIDTH//2 - 70, SCREEN_HEIGHT//2 + 50))

        # 恭喜通关界面
        if game_win:
            screen.blit(title_font.render("恭喜通关！", True, GOLD), (SCREEN_WIDTH//2 - 140, SCREEN_HEIGHT//2 - 80))
            screen.blit(font.render(f"最终分数：{score}", True, WHITE), (SCREEN_WIDTH//2 - 90, SCREEN_HEIGHT//2))
            screen.blit(font.render("你成功击败了所有BOSS", True, WHITE), (SCREEN_WIDTH//2 - 120, SCREEN_HEIGHT//2 + 40))
            screen.blit(font.render("按 R 重新开始", True, WHITE), (SCREEN_WIDTH//2 - 70, SCREEN_HEIGHT//2 + 80))

        draw_touch_ui()

        pygame.display.flip()

        await asyncio.sleep(0)
    pygame.quit()

# 直接启动主循环（pygbag 以模块方式加载 main.py，__name__ 可能不是 "__main__"，
# 因此不使用 if __name__ 判断，否则浏览器版会黑屏不运行）
_page_mark('启动')
try:
    asyncio.run(main())
except Exception as _e:
    _show_error(_e)
    import asyncio as _a
    async def _hold():
        while True:
            await _a.sleep(1)
    asyncio.run(_hold())
